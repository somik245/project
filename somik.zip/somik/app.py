from flask import Flask, request, render_template, url_for
import csv

app = Flask(__name__)


def extract_students_data():
    # Read the CSV file
    with open("students.csv", "r") as file:
        reader = csv.DictReader(file)
        students = list(reader)

    return students


# Define the route for fetching student details
@app.route("/", methods=["GET"])
def get_students():
    students = extract_students_data()
    # Get the pagination parameters from the request
    # sample url = "http://127.0.0.1:5000/students?page=3&size=6"
    page_number = int(request.args.get("page", 1))
    page_size = int(request.args.get("size", 10))

    # Calculate the start and end index for pagination
    start_index = (page_number - 1) * page_size
    end_index = start_index + page_size

    # Get the students for the requested page
    paginated_students = students[start_index:end_index]

    # Render the paginated students using a Jinja template
    return render_template("students.html", students=paginated_students)


@app.route("/filter", methods=["GET"])
def filter_data():
    # Extract filter details from the query parameters
    students = extract_students_data()
    name_filter = request.args.get("name")
    age_filter = request.args.get("age")
    grade_filter = request.args.get("grade")

    if not name_filter and not age_filter and not grade_filter:
        return render_template("students.html", students=students)
    filtered_items = students

    # check for each filtering options so we can combine multiple parameters while filtering

    if name_filter:
        filtered_items = [
            item for item in students if item["name"].lower() == name_filter.lower()
        ]
    if age_filter:
        filtered_items = [item for item in filtered_items if item["age"] == age_filter]

    if grade_filter:
        filtered_items = [
            item
            for item in filtered_items
            if item["grade"].lower() == grade_filter.lower()
        ]

    return render_template("filter.html", students=filtered_items)


if __name__ == "__main__":
    app.run(debug=True)
